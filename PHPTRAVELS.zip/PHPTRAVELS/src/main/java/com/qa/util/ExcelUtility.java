package com.qa.util;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {
	
	public static XSSFWorkbook excelWorkBook;
	public static XSSFSheet excelWorkSheet;
	
	public static String getCellData(int rowNum,int colNum,String excelPath,int sheetNum) throws IOException
	{
		FileInputStream excelFile=new FileInputStream(excelPath);
		excelWorkBook=new XSSFWorkbook(excelFile);
		excelWorkSheet=excelWorkBook.getSheetAt(sheetNum);
		
		return excelWorkSheet.getRow(rowNum).getCell(colNum).getStringCellValue();
	}

}
